package scala

object ReverseSolution:

  def reverse[A](l: List[A]): List[A] =
    reverseAcc(l, Nil)

  def reverseAcc[A](l: List[A], r: List[A]): List[A] =
    l match
      case Nil     => r
      case x :: xs => reverseAcc(xs, x :: r)
