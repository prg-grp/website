package scala

object Flatten:

  def flatten[A](xss: List[List[A]]): List[A] = ???
