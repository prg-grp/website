package scala

object FactorialFunction:

  def factorialA(n: Int): Int = ???

  def factorialB(n: Int): Int = ???

  def factorialC(n: Int): Int = ???
