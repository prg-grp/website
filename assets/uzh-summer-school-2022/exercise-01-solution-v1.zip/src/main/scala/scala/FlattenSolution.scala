package scala

object FlattenSolution:

  def flatten[A](xss: List[List[A]]): List[A] =
    xss match
      case Nil              => Nil
      case Nil :: yss       => flatten(yss)
      case (y :: ys) :: yss => y :: flatten(ys :: yss)
