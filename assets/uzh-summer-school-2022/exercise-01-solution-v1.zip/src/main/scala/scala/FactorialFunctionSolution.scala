package scala

object FactorialFunctionSolution:

  def factorialA(n: Int): Int =
    var acc = 1
    for counter <- 1 to n do acc *= counter
    acc

//  // Alternative Solution:
//  def factorialA(n: Int): Int = {
//    var acc = 1
//    var counter = n
//    while (counter > 1) {
//      acc = counter * acc
//      counter -= 1
//    }
//    acc
//  }

  def factorialB(n: Int): Int =
    if n <= 1 then 1
    else n * factorialA(n - 1)

  def factorialC(n: Int): Int =
    (1 to n).foldLeft(1)(_ * _)

//  // Alternative Solution
//  def factorialC(n: Int): Int = {
//    (1 to n).foldLeft(1) { (x, y) => x * y }
//  }
