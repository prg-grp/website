package scala

object Reverse:

  def reverse[A](l: List[A]): List[A] = ???
