package scala

import org.scalatest.funsuite.AnyFunSuite

import scala.FlattenSolution.*

class FlattenTest extends AnyFunSuite:

  test("flatten1") {
    assertResult(List(1, 2, 3, 4, 5, 6)) { flatten(List(List(1), List(2, 3, 4), List(5, 6))) }
  }
  test("flatten2") { assertResult(Nil) { flatten(Nil) } }
  test("flatten3") { assertResult(Nil) { flatten(List(Nil)) } }
  test("flatten4") {
    assertResult(List(1, 2, 3)) {
      flatten(List(Nil, List(1), Nil, List(2), Nil, List(3), Nil, Nil, Nil))
    }
  }
