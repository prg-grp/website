package scala

import org.scalatest.funsuite.AnyFunSuite

import scala.FactorialFunctionSolution.*

class FactorialFunctionTest extends AnyFunSuite:

  private def testFactorial(fac: (n: Int) => Int) =
    assertResult(1) { fac(0) }
    assertResult(1) { fac(1) }
    assertResult(6) { fac(3) }
    assertResult(3628800) { fac(10) }

  test("factorialA") { testFactorial(factorialA) }
  test("factorialB") { testFactorial(factorialB) }
  test("factorialC") { testFactorial(factorialC) }
