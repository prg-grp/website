package scala

import org.scalatest.funsuite.AnyFunSuite
import PaneoNumberAdditionSolution.*

class PaneoNumberAdditionTest extends AnyFunSuite:

  private val one = Succ(Zero)
  private val two = Succ(Succ(Zero))
  private val three = Succ(Succ(Succ(Zero)))
  private val five = Succ(Succ(Succ(Succ(Succ(Zero)))))

  test("add one zero") { assertResult(one) { add(one, Zero) } }
  test("add zero five") { assertResult(five) { add(Zero, five) } }
  test("add one one") { assertResult(two) { add(one, one) } }
  test("add two three") { assertResult(five) { add(two, three) } }
