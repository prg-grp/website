package scala

import org.scalatest.funsuite.AnyFunSuite

import scala.ReverseSolution.*

class ReverseTest extends AnyFunSuite:

  test("nil") { assertResult(Nil) { reverse(Nil) } }
  test("singleton") { assertResult(List(1)) { reverse(List(1)) } }
  test("reverse") { assertResult(List(3, 2, 1)) { reverse(List(1, 2, 3)) } }
  test("dont use flatten for reverse") {
    assertResult(List(List(3, 4), List(1, 2))) { reverse(List(List(1, 2), List(3, 4))) }
  }
