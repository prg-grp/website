package first_class_functions

import org.scalatest.funsuite.AnyFunSuite
import ScalaFns.*

class ScalaFnsTest extends AnyFunSuite:

  // If you are unfamiliar with implementing unit tests in Scala,
  // the test cases from previous examples can be used as examples

  test("TODO") {
    true
  }
