package first_class_functions

import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.prop.TableDrivenPropertyChecks.*

import definitions.FAEBase.*
import definitions.FLAEBase.*
import LetSolution.*

class LetTest extends AnyFunSuite:

  // implicitly convert
  //   numbers to LNums or Nums, and
  //   Symbols to LIds or Ids
  given Conversion[Int, LNum] with
    def apply(n: Int): LNum = LNum(n)
  given Conversion[Int, Num] with
    def apply(n: Int): Num = Num(n)
  given Conversion[String, LId] with
    def apply(s: String): LId = LId(s)
  given Conversion[String, Id] with
    def apply(s: String): Id = Id(s)

  private val testcases = Table(
    ("name", "expectation", "expr"),
    ("num", Num(3), preprocLet(LNum(3))),
    ("id", Id("x"), preprocLet(LId("x"))),
    ("fun", Fun("x", Id("x")), preprocLet(LFun("x", LId("x")))),
    ("let", App(Fun("x", Id("x")), Num(3)), preprocLet(LLet("x", LNum(3), "x"))),
    (
      "add",
      Add(Add(Num(3), Num(4)), Add(Num(6), Num(7))),
      preprocLet(LAdd(LAdd(LNum(3), LNum(4)), LAdd(LNum(6), LNum(7))))
    ),
    (
      "sub",
      Sub(Sub(Num(3), Num(4)), Sub(Num(6), Num(7))),
      preprocLet(LSub(LSub(LNum(3), LNum(4)), LSub(LNum(6), LNum(7))))
    ),
    ("let fun", Fun("y", Add(3, "y")), interp(preprocLet(LLet("x", 3, LFun("y", LAdd("x", "y")))))),
    (
      "fun app",
      Num(12),
      interp(preprocLet(LApp(LLet("x", 3, LFun("y", LAdd("x", "y"))), LAdd(4, 5))))
    ),
    (
      "let fun app",
      Num(11),
      interp(preprocLet(LLet("inc", LFun("x", LAdd("x", 1)), LAdd(LApp("inc", 4), LApp("inc", 5)))))
    )
    // You may write additional tests if you want... :
  )

  forAll(testcases) { case (name, expectation, res) =>
    test(s"Interpret $name") {
      assertResult(expectation) { res }
    }
  }
