package first_class_functions

import org.scalatest.funsuite.AnyFunSuite

import ScalaFnsSolution.*

class ScalaFnsTestSolution extends AnyFunSuite:

  test("square1") { assertResult(List(1, 4, 9)) { square(List(1, 2, 3)) } }
  test("square2") { assertResult(List(1, 4, 9)) { square(List(-1, -2, -3)) } }

  test("apply twice1") {
    assertResult(List(1, 16, 81)) {
      val squareTwice = applyTwice(square)
      squareTwice(List(-1, -2, -3))
    }
  }

  test("apply twice2") {
    assertResult(10) {
      applyTwice((x: Int) => -x)(10)
    }
  }
