package first_class_functions

import org.scalatest.funsuite.AnyFunSuite

import definitions.MFAEBase.*
import MFAEFnsSolution.{given, *}

class MFAEFnsTestSolution extends AnyFunSuite:

  // example
  test("1") { assertResult(MNum(3)) { interpMultiarg(MApp(exampleFun, List(1, 2))) } }
  test("2") { assertResult(MNum(42)) { interpMultiarg(MApp(exampleFun, List(40, 2))) } }

  // If you are unfamiliar with implementing unit tests in Scala,
  // the test cases from previous examples can be used as examples

  // Some helper functions that are used in the tests
  private val double = MFun("double", MAdd("double", "double"))
  private val increment = MFun("inc", MAdd("inc", 1))

  test("apply twice1") {
    assertResult(MNum(20)) {
      interpMultiarg(MApp(MApp(applyTwice, double), MNum(5)))
    }
  }

  test("apply twice2") {
    assertResult(MNum(7)) {
      interpMultiarg(MApp(MApp(applyTwice, increment), MNum(5)))
    }
  }

  test("combine1") {
    assertResult(MNum(12)) {
      interpMultiarg(MApp(MApp(combineFuns, List(increment, double)), MNum(5)))
    }
  }

  test("combine2") {
    assertResult(MNum(11)) {
      interpMultiarg(MApp(MApp(combineFuns, List(double, increment)), MNum(5)))
    }
  }
