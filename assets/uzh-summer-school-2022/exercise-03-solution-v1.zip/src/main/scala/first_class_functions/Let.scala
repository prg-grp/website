package first_class_functions

import definitions.FAEBase.FAE
import definitions.FLAEBase.FLAE

object Let:
  def preprocLet(expr: FLAE): FAE = ???
