package first_class_functions

import definitions.FAEBase.*
import definitions.FLAEBase.*

object LetSolution:
  def preprocLet(expr: FLAE): FAE = expr match
    case LNum(n)                     => Num(n)
    case LAdd(lhs, rhs)              => Add(preprocLet(lhs), preprocLet(rhs))
    case LSub(lhs, rhs)              => Sub(preprocLet(lhs), preprocLet(rhs))
    case LLet(name, namedExpr, body) => App(Fun(name, preprocLet(body)), preprocLet(namedExpr))
    case LId(id)                     => Id(id)
    case LFun(param, body)           => Fun(param, preprocLet(body))
    case LApp(funExpr, arg)          => App(preprocLet(funExpr), preprocLet(arg))
