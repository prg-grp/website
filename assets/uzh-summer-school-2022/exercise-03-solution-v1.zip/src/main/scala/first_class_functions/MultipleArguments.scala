package first_class_functions

import definitions.FLAEBase.FLAE
import definitions.MFLAEBase.MFLAE

object MultipleArguments:
  def preprocMultiarg(expr: MFLAE): FLAE = ???
