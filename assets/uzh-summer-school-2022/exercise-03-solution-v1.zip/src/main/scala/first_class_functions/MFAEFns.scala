package first_class_functions

import definitions.MFAEBase.*

object MFAEFns:

  // Some implicit conversions you may find helpful
  given Conversion[String, List[String]] with
    def apply(s: String): List[String] = List(s)
  given Conversion[MFAE, List[MFAE]] with
    def apply(x: MFAE): List[MFAE] = List(x)
  given Conversion[String, MId] with
    def apply(x: String): MId = MId(x)
  given Conversion[Int, MNum] with
    def apply(x: Int): MNum = MNum(x)

  // example
  val exampleFun: MFun = MFun(List("a", "b"), MAdd("a", "b"))
