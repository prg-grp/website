package first_class_functions

import definitions.MFAEBase.*

object MFAEFnsSolution:

  // Some implicit conversions you may find helpful
  given Conversion[String, List[String]] with
    def apply(s: String): List[String] = List(s)
  given Conversion[MFAE, List[MFAE]] with
    def apply(x: MFAE): List[MFAE] = List(x)
  given Conversion[String, MId] with
    def apply(x: String): MId = MId(x)
  given Conversion[Int, MNum] with
    def apply(x: Int): MNum = MNum(x)

  // example
  val exampleFun: MFun = MFun(List("a", "b"), MAdd("a", "b"))

  // --------------------------------------------
  // --- PUT ALL YOUR CHANGES BELOW THIS LINE ---
  // --------------------------------------------

  // Function that applies another function twice
  val applyTwice: MFun =
    MFun("function", MFun("param", MApp(MId("function"), MApp(MId("function"), MId("param")))))

  // Function that combines two functions by applying the second one to the
  // result of the first one
  val combineFuns: MFun = MFun(
    List("function1", "function2"),
    MFun("param", MApp(MId("function2"), MApp(MId("function1"), MId("param"))))
  )
