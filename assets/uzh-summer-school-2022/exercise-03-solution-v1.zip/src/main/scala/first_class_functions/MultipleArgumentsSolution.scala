package first_class_functions

import definitions.FLAEBase.*
import definitions.MFLAEBase.*

object MultipleArgumentsSolution:
  def preprocMultiarg(expr: MFLAE): FLAE = expr match
    case MLNum(n)        => LNum(n)
    case MLAdd(lhs, rhs) => LAdd(preprocMultiarg(lhs), preprocMultiarg(rhs))
    case MLSub(lhs, rhs) => LSub(preprocMultiarg(lhs), preprocMultiarg(rhs))
    case MLId(name)      => LId(name)
    case MLLet(name, namedExpr, body) =>
      LLet(name, preprocMultiarg(namedExpr), preprocMultiarg(body))

    // recursive solution
    case MLFun(params, body) =>
      params match
        case Nil      => LFun("_", preprocMultiarg(body))
        case x :: Nil => LFun(x, preprocMultiarg(body))
        case x :: xs  => LFun(x, preprocMultiarg(MLFun(xs, body)))
    case MLApp(funExpr, args) =>
      args match
        case Nil      => LApp(preprocMultiarg(funExpr), LNum(42))
        case x :: Nil => LApp(preprocMultiarg(funExpr), preprocMultiarg(x))
        case x :: xs  => preprocMultiarg(MLApp(MLApp(funExpr, List(x)), xs))
