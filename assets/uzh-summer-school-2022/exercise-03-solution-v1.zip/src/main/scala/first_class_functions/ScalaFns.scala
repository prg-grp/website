package first_class_functions

object ScalaFns:

  ???
