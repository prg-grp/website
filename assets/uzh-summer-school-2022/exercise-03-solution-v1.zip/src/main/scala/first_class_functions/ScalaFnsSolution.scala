package first_class_functions

object ScalaFnsSolution:

  def square(l: List[Int]): List[Int] = l map (i => i * i)
  def applyTwice[A](f: A => A): A => A = (x: A) => f(f(x))
