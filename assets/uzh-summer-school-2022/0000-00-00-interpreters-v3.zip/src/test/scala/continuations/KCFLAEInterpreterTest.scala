package continuations

import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.prop.TableDrivenPropertyChecks.*
import KCFLAEInterpreter.*

import scala.annotation.tailrec

class KCFLAEInterpreterTest extends AnyFunSuite:

  private val testcases = Table(
    ("name", "expectation", "expr"),
    ("0", Closure("y", Add("x", "y"), Map("x" -> NumV(3))), Let("x", 3, Fun("y", Add("x", "y")))),
    ("1", NumV(11), Let("inc", Fun("x", Add("x", 1)), Add(App("inc", 4), App("inc", 5)))),
    ("2", Closure("x", Add("x", 1), Map()), Let("inc", Fun("x", Add("x", 1)), "inc")),
    ("3", NumV(7), Let("x", 3, App(Fun("y", Add("x", "y")), 4))),
    ("4", NumV(4), Let("x", 2, App(Let("x", 5, Fun("x", Add("x", "x"))), "x"))),
    ("5", NumV(3), BindCC("k", 3)),
    ("6", NumV(3), BindCC("k", App("k", 3))),
    ("7", NumV(3), BindCC("k", Add(1, App("k", 3)))),
    ("9", NumV(4), Add(1, BindCC("k", 3))),
    ("10", NumV(4), Add(1, BindCC("k", App("k", 3)))),
    ("11", NumV(3), App(BindCC("k", App("k", Fun("_", 3))), 1840)),
    ("12", NumV(3), BindCC("k", App("k", App("k", App("k", 3))))),
    ("13", NumV(3), App(App(BindCC("k", "k"), Fun("x", "x")), 3))
  )

  forAll(testcases) { case (name, expectation, expr) =>
    test(s"Interpret $name") {
      assertResult(expectation) { eval(expr) }
    }
  }

  test("fact CPS") {
    @tailrec
    def factCPS(n: Int, k: Int => Int): Int =
      if (n == 0) k(1)
      else factCPS(n - 1, restResult => k(n * restResult))
    assertResult(6) { factCPS(3, x => x) }
  }
