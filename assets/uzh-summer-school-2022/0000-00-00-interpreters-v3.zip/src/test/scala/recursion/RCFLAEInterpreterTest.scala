package recursion

import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.prop.TableDrivenPropertyChecks.*
import RCFLAEInterpreter.*

class RCFLAEInterpreterTest extends AnyFunSuite:

  private val testcases = Table(
    ("name", "expectation", "expr"),
    (
      "1",
      NumV(120),
      Rec("fact", Fun("n", If0("n", 1, Mult("n", App("fact", Sub("n", 1))))), App("fact", 5))
    ),
    ("2", Closure("y", Add("x", "y"), Map("x" -> NumV(3))), Let("x", 3, Fun("y", Add("x", "y")))),
    ("3", NumV(11), Let("inc", Fun("x", Add("x", 1)), Add(App("inc", 4), App("inc", 5)))),
    ("4", Closure("x", Add("x", 1), Map()), Let("inc", Fun("x", Add("x", 1)), "inc")),
    ("5", NumV(7), Let("x", 3, App(Fun("y", Add("x", "y")), 4)))
  )

  forAll(testcases) { case (name, expectation, expr) =>
    test(s"Interpret $name") {
      assertResult(expectation) { interp(expr) }
    }
  }
