package arithmetic_expressions

import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.prop.TableDrivenPropertyChecks.*
import AEInterpreter.*

class AEInterpreterTest extends AnyFunSuite:

  private val testcases = Table(
    ("name", "expectation", "expr"),
    ("Num 1", 5, Num(5)),
    ("Num 2", 15, Num(15)),
    ("Add 1", 3, Add(1, 2)),
    ("Add 2", 10, Add(5, Add(2, 3))),
    ("Add 3", 20, Add(5, 15)),
    ("Add 4", 10, Add(Num(5), Add(Num(2), Num(3)))),
    ("Add 5", 10, Add(Add(1, 2), Add(3, 4))),
    ("Sub 1", 10, Sub(15, 5)),
    ("Sub 2", 0, Sub(Add(1, 2), 3)),
    ("Sub 3", 4, Add(Num(5), Sub(Num(2), Num(3)))),
    ("Sub 4", 6, Sub(Num(5), Sub(Num(2), Num(3))))
  )

  forAll(testcases) { case (name, expectation, expr) =>
    test(s"Interpret $name") {
      assertResult(expectation) { interp(expr) }
    }
  }
