package interpreter_types

import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.prop.TableDrivenPropertyChecks.*
import RCFLAEFunFunsInterpreter.*

class RCFLAEFunFunsInterpreterTest extends AnyFunSuite:

  private val testcases = Table(
    ("name", "expectation", "expr"),
    (
      "1",
      NumV(120),
      Rec("fact", Fun("n", If0("n", 1, Mult("n", App("fact", Sub("n", 1))))), App("fact", 5))
    ),
    ("2", NumV(11), Let("inc", Fun("x", Add("x", 1)), Add(App("inc", 4), App("inc", 5)))),
    ("3", NumV(7), Let("x", 3, App(Fun("y", Add("x", "y")), 4))),
    ("4", NumV(7), Let("x", 3, App(Fun("y", Add("x", "y")), 4))),
    (
      "5",
      NumV(120),
      Rec("fact", Fun("n", If0("n", 1, Mult("n", App("fact", Sub("n", 1))))), App("fact", 5))
    )
  )

  forAll(testcases) { case (name, expectation, expr) =>
    test(s"Interpret $name") {
      assertResult(expectation) { interp(expr) }
    }
  }
