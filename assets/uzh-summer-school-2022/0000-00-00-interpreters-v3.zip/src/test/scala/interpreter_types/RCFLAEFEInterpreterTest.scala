package interpreter_types

import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.prop.TableDrivenPropertyChecks.*
import RCFLAEFEInterpreter.*

class RCFLAEFEInterpreterTest extends AnyFunSuite:

  private val fixedEnv = emptyEnv
  private val testcases = Table(
    ("name", "expectation", "expr"),
    (
      "1",
      NumV(120),
      Rec("fact", Fun("n", If0("n", 1, Mult("n", App("fact", Sub("n", 1))))), App("fact", 5))
    ),
    ("2", Closure("y", Add(Id("x"), Id("y")), fixedEnv), Let("x", 3, Fun("y", Add("x", "y")))),
    ("3", NumV(11), Let("inc", Fun("x", Add("x", 1)), Add(App("inc", 4), App("inc", 5)))),
    ("4", Closure("x", Add(Id("x"), Num(1)), fixedEnv), Let("inc", Fun("x", Add("x", 1)), "inc")),
    ("5", NumV(7), Let("x", 3, App(Fun("y", Add("x", "y")), 4)))
  )

  forAll(testcases) { case (name, expectation, expr) =>
    test(s"Interpret $name") {
      assertResult(expectation) {
        interp(expr) match
          case c: Closure => c.copy(env = fixedEnv)
          case e          => e
      }
    }
  }
