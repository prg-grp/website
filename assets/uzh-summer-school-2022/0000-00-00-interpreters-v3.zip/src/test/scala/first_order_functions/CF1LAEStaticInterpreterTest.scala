package first_order_functions

import org.scalatest.funsuite.AnyFunSuite
import CF1LAEStaticInterpreter.*

class CF1LAEStaticInterpreterTest extends AnyFunSuite:

  test("Interpret 1") {
    val funDefs = Map("fact" -> FunDef("n", If0("n", 1, Mult("n", App("fact", Sub("n", 1))))))
    assertResult(120) { interp(App("fact", 5), funDefs, Map()) }
  }

  test("Interpret 2") {
    val funDefs = Map("f" -> FunDef("n", App("g", Add("n", 5))), "g" -> FunDef("n", Sub("n", 1)))
    assertResult(9) {
      interp(App("f", 5), funDefs, Map())
    }
  }

  test("Interpret 3") {
    val funDefs = Map(
      "f" -> FunDef("y", Sub("y", 1)),
      "g" -> FunDef("y", Sub("y", 1)),
      "f" -> FunDef("x", App("g", Add("x", 3)))
    )
    assertResult(12) { interp(App("f", 10), funDefs, Map()) }
    assertResult(10) { interp(Let("x", 3, Add(Let("x", 4, Add("x", 3)), "x")), Map(), Map()) }
  }

  test("Fail interpret 1") {
    assertThrows[Exception] {
      interp(Let("n", 5, App("f", 10)), Map("f" -> FunDef("x", "n")), Map())
    }
  }

  test("Fail interpret 2") {
    assertThrows[Exception] { interp(App("f", 4), Map("f" -> FunDef("y", Add("x", "y"))), Map()) }
  }
