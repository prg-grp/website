package state

import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.prop.TableDrivenPropertyChecks.*
import SCFLAEInterpreter.*

class SCFLAEInterpreterTest extends AnyFunSuite:

  private val testcases = Table(
    ("name", "expectation", "expr"),
    ("1", NumV(1), Let("a", NewBox(1), OpenBox("a"))),
    (
      "2",
      NumV(7),
      Let(
        "a",
        NewBox(1),
        Let("f", Fun("x", Add("x", OpenBox("a"))), Seqn(SetBox("a", 2), App("f", 5)))
      )
    ),
    (
      "3",
      NumV(1),
      Let(
        "switch",
        NewBox(0),
        Let(
          "toggle",
          Fun(
            "Dummy",
            If0(OpenBox("switch"), Seqn(SetBox("switch", 1), 1), Seqn(SetBox("switch", 0), 0))
          ),
          Add(App("toggle", 42), App("toggle", 42))
        )
      )
    ),
    (
      "4",
      NumV(1),
      Let(
        "switch",
        0,
        Let(
          "toggle",
          Fun("Dummy", If0("switch", Seqn(SetId("switch", 1), 1), Seqn(SetId("switch", 0), 0))),
          Add(App("toggle", 42), App("toggle", 42))
        )
      )
    ),
    (
      "5",
      NumV(7),
      App(Fun("b1", App(Fun("b2", Seqn(SetBox("b1", 6), OpenBox("b2"))), NewBox(7))), NewBox(5))
    ),
    ("6", NumV(5), Let("b", 0, If0(Seqn(SetId("b", 5), "b"), 1, "b"))),
    ("7", NumV(9), Let("b", 4, Add("b", Seqn(SetId("b", 5), "b"))))
  )

  forAll(testcases) { case (name, expectation, expr) =>
    test(s"Interpret $name") {
      assertResult(expectation) { interp(expr)._1 }
    }
  }
