package lazy_eval

import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.prop.TableDrivenPropertyChecks.*
import CFLAELazyCachingInterpreter.*

class CFLAELazyCachingInterpreterTest extends AnyFunSuite:

  private val testcases = Table(
    ("name", "expectation", "expr"),
    ("1", NumV(4), Let("f", App("undef", "x"), 4)),
    ("2", NumV(18), Let("x", Add(4, 5), Let("y", Add("x", "x"), Let("z", "y", Let("x", 4, "z"))))),
    (
      "3",
      FClosure("y", Add(Id("x"), Id("y")), Map("x" -> EClosure(Num(4), Map(), None))),
      Let("x", 4, Fun("y", Add("x", "y")))
    ),
    ("4", FClosure("y", Add(Id("x"), Id("y")), Map()), Let("f", Fun("y", Add("x", "y")), "f"))
  )

  forAll(testcases) { case (name, expectation, expr) =>
    test(s"Interpret $name") {
      assertResult(expectation) { interp(expr) }
    }
  }
