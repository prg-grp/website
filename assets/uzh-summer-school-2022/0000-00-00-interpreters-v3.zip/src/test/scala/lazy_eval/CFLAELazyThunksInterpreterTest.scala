package lazy_eval

import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.prop.TableDrivenPropertyChecks.*
import CFLAELazyThunksInterpreter.*

class CFLAELazyThunksInterpreterTest extends AnyFunSuite:

  private val testcases = Table(
    ("name", "expectation", "expr"),
    ("1", NumV(3), Let("x", 3, "x")),
    ("2", NumV(3), App(Fun("x", "x"), 3)),
    (
      "3",
      EClosure(Fun("y", Add(Id("x"), Id("y"))), Map("x" -> EClosure(Num(3), Map()))),
      Let("x", 3, Fun("y", Add("x", "y")))
    ),
    ("4", NumV(11), Let("inc", Fun("x", Add("x", 1)), Add(App("inc", 4), App("inc", 5)))),
    (
      "5",
      EClosure(Fun("x", Add(Id("x"), Num(1))), Map()),
      Let("inc", Fun("x", Add("x", 1)), "inc")
    ),
    ("6", NumV(7), Let("x", 3, App(Fun("y", Add("x", "y")), 4))),
    ("7", NumV(4), Let("f", App("undef", "x"), 4)),
    ("8", NumV(18), Let("x", Add(4, 5), Let("y", Add("x", "x"), Let("z", "y", Let("x", 4, "z"))))),
    ("9", NumV(9), App(Let("x", 3, Fun("y", Add("x", "y"))), 6))
  )

  forAll(testcases) { case (name, expectation, expr) =>
    test(s"Interpret $name") {
      assertResult(expectation) { interp(expr) }
    }
  }
