package lazy_eval

import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.prop.TableDrivenPropertyChecks.*
import CFLAEAlmostStrictInterpreter.*

class CFLAEAlmostStrictInterpreterTest extends AnyFunSuite:

  private val testcases = Table(
    ("name", "expectation", "expr"),
    (
      "1",
      FClosure("y", Add("x", "y"), Map("x" -> EClosure(3, Map()))),
      Let("x", 3, Fun("y", Add("x", "y")))
    ),
    ("2", NumV(20), Let("x", 10, Add("x", "x"))),
    ("3", NumV(11), Let("inc", Fun("x", Add("x", 1)), Add(App("inc", 4), App("inc", 5)))),
    ("4", NumV(7), Let("x", 3, App(Fun("y", Add("x", "y")), 4))),
    ("5", NumV(4), Let("f", App("undef", "x"), 4)),
    ("6", NumV(3), App(Fun("x", 3), "y")),
    ("7", NumV(3), If0(Sub(4, 4), App(Fun("x", 3), "y"), 8)),
    (
      "8",
      EClosure(
        Id("y"),
        Map(
          "x" -> EClosure(Add(Num(4), Num(5)), Map()),
          "y" -> EClosure(Add(Id("x"), Id("x")), Map("x" -> EClosure(Add(Num(4), Num(5)), Map())))
        )
      ),
      Let("x", Add(4, 5), Let("y", Add("x", "x"), Let("z", "y", Let("x", 4, "z"))))
    )
  )

  forAll(testcases) { case (name, expectation, expr) =>
    test(s"Interpret $name") {
      assertResult(expectation) { interp(expr) }
    }
  }
