package lazy_eval

import org.scalatest.funsuite.AnyFunSuite
import CFLAELazyInterpreter.*

class CFLAELazyInterpreterTest extends AnyFunSuite:

  test("Interpret") {
    assertResult(EClosure(Num(3), Map())) { interp(App(Fun("x", Id("x")), Num(3))) }
  }

  test("Fail interpret") {
    assertThrows[Exception] { interp(Let("x", Num(10), Add(Id("x"), Id("x")))) }
  }
