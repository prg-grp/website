package lambda_calculus

import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.prop.TableDrivenPropertyChecks.*
import FEInterpreter.*

class FEInterpreterTest extends AnyFunSuite:

  private val TRUE = Fun("x", Fun("y", "x"))
  private val FALSE = Fun("x", Fun("y", "y"))
  private val IF_THEN_ELSE =
    Fun("condition", Fun("then", Fun("else", App(App("condition", "then"), "else"))))
  // Peano numbers
  private val ZERO = Fun("s", Fun("z", "z"))
  private val ONE = Fun("s", Fun("z", App("s", "z")))
  private val TWO = Fun("s", Fun("z", App("s", App("s", "z"))))
  private val THREE = Fun("s", Fun("z", App("s", App("s", App("s", "z")))))
  private val FOUR = Fun("s", Fun("z", App("s", App("s", App("s", App("s", "z"))))))
  private val SUCC = Fun("n", Fun("s", Fun("z", App("s", App(App("n", "s"), "z")))))
  private val PLUS = Fun("a", Fun("b", Fun("s", Fun("z", App(App("a", "s"), App(App("b", "s"), "z"))))))

  private val interpTestcases = Table(
    ("name", "expectation", "expr"),
    ("function", Fun("x", "x"), Fun("x", "x")),
    ("application", Fun("y", "y"), App(Fun("x", "x"), Fun("y", "y"))),
    (
      "if true symbol",
      Fun("a", "a"),
      App(App(App(IF_THEN_ELSE, TRUE), Fun("a", "a")), Fun("b", "b"))
    ),
    (
      "if false symbol",
      Fun("b", "b"),
      App(App(App(IF_THEN_ELSE, FALSE), Fun("a", "a")), Fun("b", "b"))
    ),
    ("if false bool", TRUE, App(App(App(IF_THEN_ELSE, FALSE), FALSE), TRUE)),
    ("if true bool", FALSE, App(App(App(IF_THEN_ELSE, TRUE), FALSE), TRUE)),
    ("succ(0) = 1", Fun("s",Fun("z",App(Id("s"),App(App(Fun("s",Fun("z","z")),"s"),"z")))), App(SUCC, ZERO))
  )

  private val interpConcreteAppEliminatedTestcases = Table(
    ("name", "expectation", "expr"),
    ("succ(0) = 1", ONE, App(SUCC, ZERO)),
    ("succ(2) = 3", THREE, App(SUCC, TWO)),
    ("1 + 3 = 4", FOUR, App(App(PLUS, ONE), THREE)),
    ("3 + 1 = 4", FOUR, App(App(PLUS, THREE), ONE))
  )

  // Traverses AST, performing the beta-reduction for nested applications with concrete values as function expression
  private def eliminateConcreteApplications(v: Value): Value = v match
    case Fun(param, body) => Fun(param, eliminate(body))
  private def eliminate(v: FE): FE = v match
    case Fun(param, body) => Fun(param, eliminate(body))
    case App(f, arg) => eliminate(f) match
      case Fun(param, body) => eliminate(substitute(body, param, arg))
      case f: _ => App(f, eliminate(arg))
    case i: Id => i

  forAll(interpTestcases) { case (name, expectation, expr) =>
    test(s"Interpret $name") {
      assertResult(expectation) { interp(expr) }
    }
  }
  forAll(interpConcreteAppEliminatedTestcases) { case (name, expectation, expr) =>
    test(s"Interpret eliminated $name") {
      assertResult(expectation) { eliminateConcreteApplications(interp(expr)) }
    }
  }
