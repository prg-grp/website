package small_step

import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.prop.TableDrivenPropertyChecks.*
import AESmallStepInterpreter.*

class AESmallStepInterpreterTest extends AnyFunSuite:

  private val testcases = Table(
    ("name", "expectation", "expr"),
    ("1", 11, Add(Num(6), Add(Num(2), Num(3)))),
    ("2", 4, Add(Num(5), Sub(Num(2), Num(3)))),
    ("3", 6, Sub(Num(5), Sub(Num(2), Num(3))))
  )

  forAll(testcases) { case (name, expectation, expr) =>
    test(s"Interpret $name") {
      assertResult(expectation) { interp(expr) }
    }
  }
