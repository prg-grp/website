package let

import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.prop.TableDrivenPropertyChecks.*
import LAEInterpreter.*

class LAEInterpreterTest extends AnyFunSuite:

  private val testcases = Table(
    ("name", "expectation", "expr"),
    ("1", 20, Let("x", Add(5, 5), Add("x", "x"))),
    ("2", 10, Let("x", 5, Add("x", "x"))),
    ("3", 14, Let("x", Add(5, 5), Let("y", Sub("x", 3), Add("y", "y")))),
    ("4", 4, Let("x", 5, Let("y", Sub("x", 3), Add("y", "y")))),
    ("5", 15, Let("x", 5, Add("x", Let("x", 3, 10)))),
    ("6", 8, Let("x", 5, Add("x", Let("x", 3, "x")))),
    ("7", 10, Let("x", 5, Add("x", Let("y", 3, "x")))),
    ("8", 5, Let("x", 5, Let("y", "x", "y"))),
    ("9", 5, Let("x", 5, Let("x", "x", "x")))
  )

  forAll(testcases) { case (name, expectation, expr) =>
    test(s"Eager calc $name") {
      assertResult(expectation) { eagerCalc(expr) }
    }
    test(s"Lazy calc $name") {
      assertResult(expectation) { lazyCalc(expr) }
    }
  }

  test("Difference lazy and eager calc") {
    val expr = Let("x", Add(3, "z"), Let("y", 100, "y"))
    assertResult(100) { lazyCalc(expr) }

    // This fails for eager evaluation, because z is not bound when evaluated
    // assertResult(100) { eagerCalc(expr) }
    assertThrows[Exception] { eagerCalc(expr) }
  }
