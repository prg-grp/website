package forth

import org.scalatest.funsuite.AnyFunSuite
import ForthInterpreter.*

class ForthInterpreterTest extends AnyFunSuite:

  test("Interpret") {
    val program1: ForthProgr = List(1, 2, Sum())
    val program2: ForthProgr = List(1, 2, Sum(), 7, Sum())
    val program3: ForthProgr = List(1, 2, Sum())
    val program4: ForthProgr = List(true, If(program1, program2))

    assertResult(Num(10)) { interp(program2).pop._1 }
  }
