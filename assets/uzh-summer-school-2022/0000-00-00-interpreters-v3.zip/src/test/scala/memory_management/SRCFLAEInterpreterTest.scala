package memory_management

import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.prop.TableDrivenPropertyChecks.*
import SRCFLAEInterpreter.*

class SRCFLAEInterpreterTest extends AnyFunSuite:

  private val testcases = Table(
    ("name", "expectation", "expr"),
    ("1", NumV(1), Let("a", NewBox(1), OpenBox("a"))),
    (
      "2",
      NumV(7),
      Let(
        "a",
        NewBox(1),
        Let("f", Fun("x", Add("x", OpenBox("a"))), Seqn(SetBox("a", 2), App("f", 5)))
      )
    ),
    (
      "3",
      NumV(1),
      Let(
        "switch",
        NewBox(0),
        Let(
          "toggle",
          Fun(
            "Dummy",
            If0(OpenBox("switch"), Seqn(SetBox("switch", 1), 1), Seqn(SetBox("switch", 0), 0))
          ),
          Add(App("toggle", 42), App("toggle", 42))
        )
      )
    ),
    (
      "4",
      NumV(1),
      Let(
        "switch",
        0,
        Let(
          "toggle",
          Fun("Dummy", If0("switch", Seqn(SetId("switch", 1), 1), Seqn(SetId("switch", 0), 0))),
          Add(App("toggle", 42), App("toggle", 42))
        )
      )
    ),
    (
      "5",
      NumV(7),
      App(Fun("b1", App(Fun("b2", Seqn(SetBox("b1", 6), OpenBox("b2"))), NewBox(7))), NewBox(5))
    ),
    ("6", NumV(5), Let("b", 0, If0(Seqn(SetId("b", 5), "b"), 1, "b"))),
    ("7", NumV(9), Let("b", 4, Add("b", Seqn(SetId("b", 5), "b")))),
    (
      "8",
      NumV(120),
      Rec("fact", Fun("n", If0("n", 1, Mult("n", App("fact", Add("n", -1))))), App("fact", 5))
    ),
    (
      "9",
      Closure("y", Add("x", "y"), Map("x" -> 0)),
      Let("x", 3, Fun("y", Add("x", "y")))
    ),
    ("10", NumV(11), Let("inc", Fun("x", Add("x", 1)), Add(App("inc", 4), App("inc", 5)))),
    ("11", Closure("x", Add("x", 1), Map()), Let("inc", Fun("x", Add("x", 1)), "inc")),
    ("12", NumV(7), Let("x", 3, App(Fun("y", Add("x", "y")), 4)))
  )

  forAll(testcases) { case (name, expectation, expr) =>
    test(s"Interpret $name") {
      assertResult(expectation) { interp(expr)._1 }
    }
  }
