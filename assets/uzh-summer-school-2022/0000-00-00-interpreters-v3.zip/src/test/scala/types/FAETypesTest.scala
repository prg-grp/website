package types

import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.prop.TableDrivenPropertyChecks.*
import FAETypes.*

class FAETypesTest extends AnyFunSuite:

  private val applyFunToNum =
    Fun("f", TFun(TNum(), TNum()), Fun("x", TNum(), App(Id("f"), Id("x"))))
  private val doubleNum = Fun("x", TNum(), Add(Id("x"), Id("x")))
  private val testcases = Table(
    ("name", "expectation", "expr"),
    ("1", TNum(), Add(Num(1), Num(1))),
    ("2", TNum(), App(Fun("n", TNum(), Add(Id("n"), Id("n"))), Num(10))),
    ("3", TFun(TNum(), TNum()), doubleNum),
    ("4", TNum(), App(doubleNum, Num(0))),
    ("5", TFun(TFun(TNum(), TNum()), TFun(TNum(), TNum())), applyFunToNum),
    ("6", TFun(TNum(), TNum()), App(applyFunToNum, doubleNum)),
    ("7", TNum(), App(App(applyFunToNum, doubleNum), Num(0))),
    (
      "8",
      TFun(TFun(TFun(TNum(), TNum()), TNum()), TNum()),
      Fun(
        "z",
        TFun(TFun(TNum(), TNum()), TNum()),
        App(Id("z"), Fun("z", TNum(), Add(Id("z"), Id("z"))))
      )
    ),
    (
      "9",
      TFun(TFun(TNum(), TNum()), TNum()),
      Fun(
        "z",
        TFun(TNum(), TNum()),
        App(Fun("z", TNum(), Add(Id("z"), Id("z"))), App(Id("z"), Num(0)))
      )
    )
  )

  forAll(testcases) { case (name, expectation, expr) =>
    test(s"TypeOf $name") {
      assertResult(expectation) { typeOf(expr) }
    }
  }

  private val failCases = Table(
    ("name", "expr"),
    ("1", App(Num(0), Num(0))),
    ("2", Fun("x", TFun(TNum(), TNum()), Add(Id("x"), Id("x")))),
    ("3", App(applyFunToNum, Num(0))),
    ("4", App(App(applyFunToNum, doubleNum), doubleNum))
  )

  forAll(failCases) { case (name, expr) =>
    test(s"Fail TypeOf $name") {
      assertThrows[Exception] { typeOf(expr) }
    }
  }
