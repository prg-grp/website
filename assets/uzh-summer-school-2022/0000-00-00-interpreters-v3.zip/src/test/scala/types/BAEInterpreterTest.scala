package types

import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.prop.TableDrivenPropertyChecks.*
import BAEInterpreter.*

class BAEInterpreterTest extends AnyFunSuite:

  private val testcases = Table(
    ("name", "expectation", "expr"),
    ("1", Num(10), Add(5, Add(2, 3))),
    ("2", Num(7), Add(5, IfA(Bool(true), Num(2), Num(3))))
  )

  forAll(testcases) { case (name, expectation, expr) =>
    test(s"Interpret $name") {
      assertResult(expectation) { interpretEXP(expr) }
    }
  }
