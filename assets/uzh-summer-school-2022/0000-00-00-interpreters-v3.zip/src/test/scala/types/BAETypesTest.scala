package types

import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.prop.TableDrivenPropertyChecks.*
import BAETypes.*

class BAETypesTest extends AnyFunSuite:

  private val testcases = Table(
    ("name", "expectation", "expr"),
    ("1", TNum(), Add(Num(1), Num(1))),
    ("2", TBool(), And(Bool(true), Bool(false))),
    ("3", TNum(), If(Bool(true), Num(1), Num(2))),
    ("4", TNum(), Add(If(Not(Bool(true)), Num(1), Num(2)), Num(10))),
    ("5", TBool(), Not(If(Bool(true), Bool(true), Bool(false))))
  )

  forAll(testcases) { case (name, expectation, expr) =>
    test(s"Interpret $name") {
      assertResult(expectation) { typeOf(expr) }
    }
  }
