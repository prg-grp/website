package first_class_functions

import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.prop.TableDrivenPropertyChecks.*
import FLAEStaticInterpreter.*

class FLAEStaticInterpreterTest extends AnyFunSuite:

  private val testcases = Table(
    ("name", "expectation", "expr"),
    ("1", VClosure("y", Add("x", "y"), Map("x" -> VNum(3))), Let("x", 3, Fun("y", Add("x", "y")))),
    ("2", VNum(11), Let("inc", Fun("x", Add("x", 1)), Add(App("inc", 4), App("inc", 5)))),
    ("3", VClosure("x", Add("x", 1), Map()), Let("inc", Fun("x", Add("x", 1)), "inc")),
    ("4", VNum(7), Let("x", 3, App(Fun("y", Add("x", "y")), 4))),
    ("5", VNum(4), Let("x", 2, App(Let("x", 5, Fun("x", Add("x", "x"))), "x")))
  )

  forAll(testcases) { case (name, expectation, expr) =>
    test(s"Interpret $name") {
      assertResult(expectation) { interp(expr) }
    }
  }
