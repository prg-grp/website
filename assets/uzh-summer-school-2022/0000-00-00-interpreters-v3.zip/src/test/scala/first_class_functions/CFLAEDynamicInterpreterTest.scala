package first_class_functions

import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.prop.TableDrivenPropertyChecks.*
import CFLAEDynamicInterpreter.*

class CFLAEDynamicInterpreterTest extends AnyFunSuite:

  private val testcases = Table(
    ("name", "expectation", "expr"),
    (
      "1",
      Num(120),
      Let("fact", Fun("n", If0("n", 1, Mult("n", App("fact", Sub("n", 1))))), App("fact", 5))
    ),
    ("2", Num(9), Let("x", 3, Let("f", Fun("y", Add("x", "y")), Let("x", 5, App("f", 4))))),
    ("3", Fun("y", Add("x", "y")), Let("x", 3, Fun("y", Add("x", "y")))),
    ("4", Num(11), Let("inc", Fun("x", Add("x", 1)), Add(App("inc", 4), App("inc", 5)))),
    ("5", Num(4), Let("x", 2, App(Let("x", 5, Fun("x", Add("x", "x"))), "x")))
  )

  forAll(testcases) { case (name, expectation, expr) =>
    test(s"Interpret $name") {
      assertResult(expectation) { interp(expr) }
    }
  }
