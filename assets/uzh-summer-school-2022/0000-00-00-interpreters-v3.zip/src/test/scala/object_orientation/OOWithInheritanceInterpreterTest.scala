package object_orientation

import org.scalatest.BeforeAndAfter
import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.prop.TableDrivenPropertyChecks.*
import OOWithInheritanceInterpreter.*

class OOWithInheritanceInterpreterTest extends AnyFunSuite with BeforeAndAfter:

  private val pizzaTestclasses = Map(
    "True" -> Class(
      "Object",
      List.empty,
      Map(
        "ifThenElse" -> Method(List("thenExp", "elseExp"), Id("thenExp")),
        "and" -> Method(List("x"), Id("x"))
      )
    ),
    "False" -> Class(
      "Object",
      List.empty,
      Map(
        "ifThenElse" -> Method(List("thenExp", "elseExp"), Id("elseExp")),
        "and" -> Method(List("x"), Id("this"))
      )
    ),
    "Food" -> Class(
      "Object",
      List("organic"),
      Map(
        "tastesBetterThan" ->
          Method(
            List("other"),
            Invoke(
              FAcc(Id("this"), "organic"),
              "ifThenElse",
              List(New("True", List.empty), FAcc(Id("otherFood"), "organic"))
            )
          )
      )
    ),
    "Pizza" -> Class(
      "Food",
      List("hasCheese"),
      Map(
        "tastesBetterThan" ->
          Method(
            List("other"),
            Invoke(FAcc(Id("this"), "organic"), "and", List(FAcc(Id("this"), "hasCheese")))
          )
      )
    )
  )

  test("Pizza") {
    assertResult(Object("True", List())) {
      interp(
        Invoke(
          New("Pizza", List(New("True", List.empty), New("True", List.empty))),
          "tastesBetterThan",
          List(New("Food", List(New("True", List.empty))))
        ),
        Map(),
        pizzaTestclasses
      )
    }
  }

  private val dummyClass = Class("Object", Nil, Map.empty)
  private val newDummy = New("Dummy", Nil)
  private val dummyVal = Object("Dummy", Nil)

  private val altDummyClass = Class("Object", Nil, Map.empty)
  private val newAltDummy = New("AltDummy", Nil)
  private val altDummyVal = Object("AltDummy", Nil)

  private val testclassesBase = Map("Dummy" -> dummyClass, "AltDummy" -> altDummyClass)
  private var testclasses: Map[String, Class] = Map.empty

  before {
    testclasses = Map.empty
  }

  private def eval(e: Expr) = {
    interp(e, Map.empty, testclassesBase ++ testclasses)
  }

  given Conversion[String, Expr] with
    def apply(s: String): Expr = Id(s)

  test("method call") {
    testclasses = Map("foo" -> Class("Object", Nil, Map("foo" -> Method(Nil, newDummy))))
    val result = eval(Invoke(New("foo", Nil), "foo", Nil))
    assert(result === dummyVal)
  }

  test("method call with multiple methods") {
    val fooClass = Class(
      "Object",
      Nil,
      Map(
        "bar" -> Method(Nil, Id("error")),
        "baz" -> Method(Nil, Id("error")),
        "foo" -> Method(Nil, newDummy),
        "zort" -> Method(Nil, Id("error"))
      )
    )
    testclasses = Map("foo" -> fooClass)
    val result = eval(Invoke(New("foo", Nil), "foo", Nil))
    assert(result === dummyVal)
  }

  test("method call with argument access") {
    testclasses = Map("foo" -> Class("Object", Nil, Map("foo" -> Method(List("x"), Id("x")))))
    val result = eval(Invoke(New("foo", Nil), "foo", List(newDummy)))
    assert(result === dummyVal)
  }

  test("method call with multiple arguments") {
    testclasses =
      Map("foo" -> Class("Object", Nil, Map("foo" -> Method(List("x", "y", "z"), Id("y")))))
    val result = eval(Invoke(New("foo", Nil), "foo", List(newAltDummy, newDummy, newAltDummy)))
    assert(result === dummyVal)
  }

  test("method call with this access") {
    testclasses = Map("foo" -> Class("Object", Nil, Map("foo" -> Method(Nil, Id("this")))))
    val result = eval(Invoke(New("foo", Nil), "foo", Nil))
    assert(result === Object("foo", Nil))
  }

  test("method call with field access") {
    testclasses =
      Map("foo" -> Class("Object", List("bar"), Map("foo" -> Method(Nil, FAcc("this", "bar")))))
    val result = eval(Invoke(New("foo", List(newDummy)), "foo", Nil))
    assert(result === dummyVal)
  }

  test("set and get field") {
    testclasses = Map("foo" -> Class("Object", List("bar"), Map.empty))
    val result = eval(FAcc(New("foo", List(newDummy)), "bar"))
    assert(result === dummyVal)
  }

  test("set and get with multiple fields") {
    testclasses = Map("foo" -> Class("Object", List("bar", "foo", "baz"), Map.empty))
    val result = eval(FAcc(New("foo", List(newAltDummy, newDummy, newAltDummy)), "foo"))
    assert(result === dummyVal)
  }

  test("set and get field with name \"this\"") {
    testclasses = Map("foo" -> Class("Object", List("this"), Map.empty))
    val result = eval(FAcc(New("foo", List(newDummy)), "this"))
    assert(result === dummyVal)
  }

  test("field does not shadow this") {
    testclasses = Map("foo" -> Class("Object", List("this"), Map("foo" -> Method(Nil, Id("this")))))
    val result = eval(Invoke(New("foo", List(newDummy)), "foo", Nil))
    assert(result === Object("foo", List(dummyVal)))
  }

  test("arg does not shadow this") {
    testclasses = Map("foo" -> Class("Object", Nil, Map("foo" -> Method(List("this"), Id("this")))))
    val result = eval(Invoke(New("foo", Nil), "foo", List(newDummy)))
    assert(result === Object("foo", Nil))
  }

  test("arg shadows field") {
    testclasses =
      Map("foo" -> Class("Object", List("bar"), Map("foo" -> Method(List("bar"), Id("bar")))))
    val result = eval(Invoke(New("foo", List(newAltDummy)), "foo", List(newDummy)))
    assert(result === dummyVal)
  }

  test("set and get field from parent") {
    testclasses = Map(
      "foo" -> Class("Object", List("field"), Map.empty),
      "Bar" -> Class("foo", Nil, Map.empty)
    )
    val result = eval(FAcc(New("Bar", List(newDummy)), "field"))
    assert(result === dummyVal)
  }

  test("child fields before parent fields") {
    testclasses = Map(
      "foo" -> Class("Object", List("pField"), Map.empty),
      "Bar" -> Class("foo", List("cField"), Map.empty)
    )
    val result = eval(FAcc(New("Bar", List(newDummy, newAltDummy)), "pField"))
    assert(result === altDummyVal)
  }

  test("access methods from parent") {
    testclasses = Map(
      "foo" -> Class("Object", Nil, Map("foo" -> Method(Nil, newDummy))),
      "Bar" -> Class("foo", Nil, Map.empty)
    )
    val result = eval(Invoke(New("Bar", Nil), "foo", Nil))
    assert(result === dummyVal)
  }

  test("access methods from ancestor") {
    testclasses = Map(
      "foo" -> Class("Object", Nil, Map("foo" -> Method(Nil, newDummy))),
      "Bar" -> Class("foo", Nil, Map.empty),
      "Baz" -> Class("foo", Nil, Map.empty)
    )
    val result = eval(Invoke(New("Baz", Nil), "foo", Nil))
    assert(result === dummyVal)
  }

  test("does not override field in child") {
    testclasses = Map(
      "foo" -> Class("Object", List("pField"), Map.empty),
      "Bar" -> Class("foo", List("pField", "cField"), Map.empty)
    )
    val result = eval(FAcc(New("Bar", List(newAltDummy, newDummy, newAltDummy)), "cField"))
    assert(result === dummyVal)
  }

  test("child field shadows parent field") {
    testclasses = Map(
      "foo" -> Class("Object", List("field"), Map.empty),
      "Bar" -> Class("foo", List("field"), Map.empty)
    )
    val result = eval(FAcc(New("Bar", List(newAltDummy, newDummy)), "field"))
    assert(result === altDummyVal)
  }

  test("override methods in child") {
    testclasses = Map(
      "foo" -> Class("Object", Nil, Map("foo" -> Method(Nil, newDummy))),
      "Bar" -> Class("foo", Nil, Map("foo" -> Method(Nil, newAltDummy)))
    )
    val result = eval(Invoke(New("Bar", Nil), "foo", Nil))
    assert(result === altDummyVal)
  }

  test("override methods in grandchild") {
    testclasses = Map(
      "foo" -> Class("Object", Nil, Map("foo" -> Method(Nil, newDummy))),
      "Bar" -> Class("foo", Nil, Map.empty),
      "Baz" -> Class("foo", Nil, Map("foo" -> Method(Nil, newAltDummy)))
    )
    val result = eval(Invoke(New("Baz", Nil), "foo", Nil))
    assert(result === altDummyVal)
  }
