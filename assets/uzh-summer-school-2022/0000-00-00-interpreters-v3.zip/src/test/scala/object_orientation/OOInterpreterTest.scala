package object_orientation

import org.scalatest.BeforeAndAfter
import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.prop.TableDrivenPropertyChecks.*
import OOInterpreter.*

class OOInterpreterTest extends AnyFunSuite with BeforeAndAfter:

  private val firstTestclasses = Map(
    "True" -> Class(Nil, Map("and" -> Method(List("other"), Id("other")))),
    "False" -> Class(Nil, Map("and" -> Method(List("other"), Id("this")))),
    "Box" -> Class(List("v"), Map("get" -> Method(Nil, FAcc(Id("this"), "v"))))
  )

  private val tE = New("True", Nil)
  private val tV = Object("True", Nil)
  private val fE = New("False", Nil)
  private val fV = Object("False", Nil)

  private val testcases = Table(
    ("name", "expectation", "expr"),
    ("1", fV, Invoke(New("Box", List(fE)), "get", Nil)),
    ("2", tV, Invoke(tE, "and", List(tE))),
    ("3", fV, Invoke(fE, "and", List(tE)))
  )

  forAll(testcases) { case (name, expectation, expr) =>
    test(s"Interpret $name") {
      assertResult(expectation) { interp(expr, Map(), firstTestclasses) }
    }
  }

  private val dummyClass = Class(Nil, Map.empty)
  private val newDummy = New("Dummy", Nil)
  private val dummyVal = Object("Dummy", Nil)

  private val altDummyClass = Class(Nil, Map.empty)
  private val newAltDummy = New("AltDummy", Nil)
  private val altDummyVal = Object("AltDummy", Nil)

  private val testclassesBase = Map("Dummy" -> dummyClass, "AltDummy" -> altDummyClass)
  private var testclasses: Map[String, Class] = Map.empty

  before {
    testclasses = Map.empty
  }

  private def eval(e: Expr) = {
    interp(e, Map.empty, testclassesBase ++ testclasses)
  }
  given Conversion[String, Expr] with
    def apply(s: String): Expr = Id(s)

  test("method call") {
    testclasses = Map("foo" -> Class(Nil, Map("foo" -> Method(Nil, newDummy))))
    val result = eval(Invoke(New("foo", Nil), "foo", Nil))
    assert(result === dummyVal)
  }

  test("method call with multiple methods") {
    val fooClass = Class(
      Nil,
      Map(
        "bar" -> Method(Nil, Id("error")),
        "baz" -> Method(Nil, Id("error")),
        "foo" -> Method(Nil, newDummy),
        "zort" -> Method(Nil, Id("error"))
      )
    )
    testclasses = Map("foo" -> fooClass)
    val result = eval(Invoke(New("foo", Nil), "foo", Nil))
    assert(result === dummyVal)
  }

  test("method call with argument access") {
    testclasses = Map("foo" -> Class(Nil, Map("foo" -> Method(List("x"), Id("x")))))
    val result = eval(Invoke(New("foo", Nil), "foo", List(newDummy)))
    assert(result === dummyVal)
  }

  test("method call with multiple arguments") {
    testclasses = Map("foo" -> Class(Nil, Map("foo" -> Method(List("x", "y", "z"), Id("y")))))
    val result = eval(Invoke(New("foo", Nil), "foo", List(newAltDummy, newDummy, newAltDummy)))
    assert(result === dummyVal)
  }

  test("method call with this access") {
    testclasses = Map("foo" -> Class(Nil, Map("foo" -> Method(Nil, Id("this")))))
    val result = eval(Invoke(New("foo", Nil), "foo", Nil))
    assert(result === Object("foo", Nil))
  }

  test("method call with field access") {
    testclasses = Map("foo" -> Class(List("bar"), Map("foo" -> Method(Nil, FAcc("this", "bar")))))
    val result = eval(Invoke(New("foo", List(newDummy)), "foo", Nil))
    assert(result === dummyVal)
  }

  test("set and get field") {
    testclasses = Map("foo" -> Class(List("bar"), Map.empty))
    val result = eval(FAcc(New("foo", List(newDummy)), "bar"))
    assert(result === dummyVal)
  }

  test("set and get with multiple fields") {
    testclasses = Map("foo" -> Class(List("bar", "foo", "baz"), Map.empty))
    val result = eval(FAcc(New("foo", List(newAltDummy, newDummy, newAltDummy)), "foo"))
    assert(result === dummyVal)
  }

  test("set and get field with name \"this\"") {
    testclasses = Map("foo" -> Class(List("this"), Map.empty))
    val result = eval(FAcc(New("foo", List(newDummy)), "this"))
    assert(result === dummyVal)
  }

  test("field does not shadow this") {
    testclasses = Map("foo" -> Class(List("this"), Map("foo" -> Method(Nil, Id("this")))))
    val result = eval(Invoke(New("foo", List(newDummy)), "foo", Nil))
    assert(result === Object("foo", List(dummyVal)))
  }

  test("arg does not shadow this") {
    testclasses = Map("foo" -> Class(Nil, Map("foo" -> Method(List("this"), Id("this")))))
    val result = eval(Invoke(New("foo", Nil), "foo", List(newDummy)))
    assert(result === Object("foo", Nil))
  }

  test("arg shadows field") {
    testclasses = Map("foo" -> Class(List("bar"), Map("foo" -> Method(List("bar"), Id("bar")))))
    val result = eval(Invoke(New("foo", List(newAltDummy)), "foo", List(newDummy)))
    assert(result === dummyVal)
  }
