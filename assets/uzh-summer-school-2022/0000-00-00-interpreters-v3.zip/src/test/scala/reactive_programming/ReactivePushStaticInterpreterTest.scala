package reactive_programming

import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.prop.TableDrivenPropertyChecks.*
import ReactivePushStaticInterpreter.*

class ReactivePushStaticInterpreterTest extends AnyFunSuite:

  private val testcases = Table(
    ("name", "expectation", "expr"),
    ("1", NumV(2), Let("f", Fun("x", Add("x", "x")), App("f", If0(0, 1, 2)))),
    ("2", NumV(1), CurrVal(NewVar(1))),
    ("3", Var(7, 8, 9), Let("x", NewVar(NewVar(1)), CurrVal("x"))),
    ("4", NumV(2), CurrVal(NewVar(Let("x", If0(0, 1, 2), Add("x", "x"))))),
    ("5", NumV(2), Let("x", 1, CurrVal(Let("x", 2, NewVar("x"))))),
    ("6", NumV(2), CurrVal(Let("x", NewVar(1), Seqn(SetVar("x", 2), "x")))),
    ("7", NumV(3), Let("x", NewVar(1), Let("y", Add("x", 1), Seqn(SetVar("x", 2), CurrVal("y"))))),
    (
      "8",
      NumV(4),
      Let(
        "x",
        NewVar(1),
        Let(
          "y",
          NewVar(2),
          Let(
            "z",
            NewVar(3),
            Let(
              "if",
              If0("x", "y", "z"),
              Seqn(Seqn(SetVar("x", 0), SetVar("y", 4)), CurrVal("if"))
            )
          )
        )
      )
    ),
    (
      "9",
      NumV(5),
      Let(
        "x",
        NewVar(1),
        Let(
          "y",
          NewVar(2),
          Let(
            "z",
            Add("x", "y"),
            Add(CurrVal("z"), Seqn(SetVar("y", CurrVal("x")), CurrVal("z")))
          )
        )
      )
    ),
    (
      "10",
      NumV(2),
      Let(
        "v",
        NewVar(0),
        Let(
          "f",
          Fun("x", If0("x", "x", Add("x", 1))),
          Let("res", App("f", "v"), Seqn(SetVar("v", 1), CurrVal("res")))
        )
      )
    ),
    (
      "11",
      NumV(1),
      Let(
        "v",
        NewVar(0),
        Let(
          "f",
          If0("v", Fun("x", Add("x", -1)), Fun("x", Add("x", 1))),
          Let("res", App("f", 0), Seqn(SetVar("v", 1), CurrVal("res")))
        )
      )
    )
  )

  forAll(testcases) { case (name, expectation, expr) =>
    test(s"Interpret $name") {
      assertResult(expectation) { interp(expr)._1 }
    }
  }

  test("time") {
    val t = interp(
      Let("t0", CurrVal(Time()), Let("tnow", Time(), Seqn(Wait(100), CurrVal(Sub("tnow", "t0")))))
    )._1 match
      case NumV(t) => t
      case _       => sys.error("Never")
    assert(100 <= t)
  }
