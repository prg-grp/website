package reactive_programming

import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.prop.TableDrivenPropertyChecks.*
import ReactivePullNoCacheInterpreter.*

class ReactivePullNoCacheInterpreterTest extends AnyFunSuite:

  private val testcases = Table(
    ("name", "expectation", "expr"),
    (
      "Standard interpreter test",
      NumV(2),
      Let("f", Fun("x", Add("x", "x")), App("f", If0(0, 1, 2)))
    ),
    ("Can create and read simple var", NumV(1), CurrVal(NewVar(1))),
    ("Can create and read nested var", Var(6), Let("x", NewVar(NewVar(1)), CurrVal("x"))),
    (
      "Can create and read complex var",
      NumV(2),
      CurrVal(NewVar(Let("x", If0(0, 1, 2), Add("x", "x"))))
    ),
    (" Static scoping for vars", NumV(2), Let("x", 1, CurrVal(Let("x", 2, NewVar("x"))))),
    (
      "Can set new value for var (box-like behavior)",
      NumV(2),
      CurrVal(Let("x", NewVar(1), Seqn(SetVar("x", 2), "x")))
    ),
    (
      "Update of dependent values",
      NumV(3),
      Let("x", NewVar(1), Let("y", Add("x", 1), Seqn(SetVar("x", 2), CurrVal("y"))))
    ),
    (
      "Complex dependency updates 1",
      NumV(4),
      Let(
        "x",
        NewVar(1),
        Let(
          "y",
          NewVar(2),
          Let(
            "z",
            NewVar(3),
            Let("if", If0("x", "y", "z"), Seqn(Seqn(SetVar("x", 0), SetVar("y", 4)), CurrVal("if")))
          )
        )
      )
    ),
    (
      "Complex dependency updates 2",
      NumV(5),
      Let(
        "x",
        NewVar(1),
        Let(
          "y",
          NewVar(2),
          Let("z", Add("x", "y"), Add(CurrVal("z"), Seqn(SetVar("y", CurrVal("x")), CurrVal("z"))))
        )
      )
    )
  )

  forAll(testcases) { case (name, expectation, expr) =>
    test(name) {
      assertResult(expectation) { interp(expr)._1 }
    }
  }
