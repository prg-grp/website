package lambda_calculus

object FEInterpreter:

  sealed trait Value
  sealed trait FE
  case class Id(name: String) extends FE
  case class Fun(param: String, body: FE) extends FE with Value
  case class App(funExp: FE, arg: FE) extends FE

  def substitute(expr: FE, substId: String, value: FE): FE = expr match
    case Id(name) => if name == substId then value else expr
    case Fun(param, body) =>
      if param == substId then expr else Fun(param, substitute(body, substId, value))
    case App(funExp, argExpr) =>
      App(substitute(funExp, substId, value), substitute(argExpr, substId, value))

  def interp(expr: FE): Value = expr match
    case Id(name) => sys.error(s"$name unbound")
    case f: Fun   => f
    case App(funExpr, argExpr) =>
      interp(funExpr) match
        case Fun(param, body) => interp(substitute(body, param, argExpr))
        case a                => sys.error(s"Expected Fun but got $a")

  given Conversion[String, FE] with
    def apply(s: String): FE = Id(s)
