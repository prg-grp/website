package higher_order_functions

import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.prop.TableDrivenPropertyChecks.*
import ArithmeticsSolution.*

class ArithmeticsTest extends AnyFunSuite:

  private val sumTestcases = Table(
    ("name", "expectation", "expr"),
    ("1", 0, List(2, 0, 1, -3)),
    ("2", 6, List(2, 0, 1, 3)),
    ("3", 0, Nil)
  )
  private val prodTestcases = Table(
    ("name", "expectation", "expr"),
    ("1", -6, List(2, 1, -3)),
    ("2", 6, List(2, 1, 3)),
    ("3", 1, Nil)
  )

  forAll(sumTestcases) { case (name, expectation, expr) =>
    test(s"Sum $name") {
      assertResult(expectation) { sum(expr) }
    }
    test(s"Sum fold $name") {
      assertResult(expectation) { sumFold(expr) }
    }
  }

  forAll(prodTestcases) { case (name, expectation, expr) =>
    test(s"Prod $name") {
      assertResult(expectation) { prod(expr) }
    }
    test(s"Prod fold $name") {
      assertResult(expectation) { prodFold(expr) }
    }
  }
