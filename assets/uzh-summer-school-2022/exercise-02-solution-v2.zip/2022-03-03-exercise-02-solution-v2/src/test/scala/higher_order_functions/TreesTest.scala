package higher_order_functions

import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.prop.TableDrivenPropertyChecks.*
import TreesSolution.*

class TreesTest extends AnyFunSuite:

  private val sumTreeTestcases = Table(
    ("name", "expectation", "expr"),
    ("1", 1, Leaf(1)),
    ("2", 3, Node(Leaf(1), Leaf(2))),
    ("3", 10, Node(Node(Leaf(1), Node(Leaf(2), Leaf(3))), Leaf(4)))
  )
  private val collectTreeTestcases = Table(
    ("name", "expectation", "expr"),
    ("1", Set("a"), Leaf("a")),
    ("2", Set("a", "b"), Node(Leaf("a"), Leaf("b"))),
    ("3", Set("a", "c", "d", "b"), Node(Node(Leaf("a"), Node(Leaf("b"), Leaf("c"))), Leaf("d")))
  )

  forAll(sumTreeTestcases) { case (name, expectation, expr) =>
    test(s"Sum tree $name") {
      assertResult(expectation) { sumTree(expr) }
    }
    test(s"Sum tree fold $name") {
      assertResult(expectation) { sumTreeFold(expr) }
    }
  }
  forAll(collectTreeTestcases) { case (name, expectation, expr) =>
    test(s"Collect tree $name") {
      assertResult(expectation) { collectTree(expr) }
    }
    test(s"Collect tree fold $name") {
      assertResult(expectation) { collectTreeFold(expr) }
    }
  }
