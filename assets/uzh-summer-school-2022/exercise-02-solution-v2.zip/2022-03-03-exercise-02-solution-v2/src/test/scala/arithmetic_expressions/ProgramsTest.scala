package arithmetic_expressions

import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.prop.TableDrivenPropertyChecks.*
import ProgramsSolution.*

class ProgramsTest extends AnyFunSuite:

  val prog1: LAE = Num(1)
  val prog2: LAE = Let("x", Num(6), Add(Id("x"), Num(1)))
  val prog3: LAE = Add(Id("x"), Add(Let("y", Num(2), Id("y")), Id("z")))

  private val progSizeTestcases = Table(
    ("name", "expectation", "expr"),
    ("1", 1, prog1),
    ("2", 5, prog2),
    ("3", 7, prog3)
  )

  private val freeVarsTestcases = Table(
    ("name", "expectation", "expr"),
    ("1", Set(), prog1),
    ("2", Set(), prog2),
    ("3", Set("x", "z"), prog3)
  )

  forAll(progSizeTestcases) { case (name, expectation, expr) =>
    test(s"Prog size $name") {
      assertResult(expectation) { progSize(expr) }
    }
    test(s"Prog size fold $name") {
      assertResult(expectation) { progSizeFold(expr) }
    }
  }

  forAll(freeVarsTestcases) { case (name, expectation, expr) =>
    test(s"Free vars $name") {
      assertResult(expectation) { freeVars(expr) }
    }
    test(s"Free vars fold $name") {
      assertResult(expectation) { freeVarsFold(expr) }
    }
  }
