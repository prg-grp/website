package first_order_functions

import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.prop.TableDrivenPropertyChecks.*

import If0Solution.*
import FibonacciSolution.*

class FibonacciTest extends AnyFunSuite:

  private val testcases = Table(
    ("expectation", "expr"),
    (0, Num(0)),
    (1, Num(1)),
    (1, Num(2)),
    (3, Num(4)),
    (5, Num(5)),
    (8, Num(6)),
    (377, Num(14)),
    (13, Let("x", 6, Add("x", 1))),
    (21, Let("x", 6, Add("x", 2))),
    (34, Let("x", 7, Add(2, "x"))),
    (55, Add(4, 6))
  )

  forAll(testcases) { case (expectation, expr: F1LAE) =>
    test("test " + expr) {
      assertResult(expectation) { interp(App("fib", expr), fibDefs) }
    }
  }

  test("sum of fibs") {
    assertResult(89) {
      interp(Add(App("fib", 9), App("fib", 10)), fibDefs)
    }
  }
