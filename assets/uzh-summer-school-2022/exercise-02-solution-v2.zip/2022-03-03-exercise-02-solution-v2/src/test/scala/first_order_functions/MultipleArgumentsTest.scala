package first_order_functions

import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.prop.TableDrivenPropertyChecks.*

import MultipleArgumentsSolution.*

class MultipleArgumentsTest extends AnyFunSuite:
  val funDefs = Map(
    "f" -> FunDef("f", List("n"), App("g", List(Add("n", 5)))),
    "g" -> FunDef("g", List("n"), Sub("n", 1))
  )

  private val testcases = Table(
    ("name", "expectation", "expr", "funDefs"),
    ("interp app0", 2, App("c", List()), Map("c" -> FunDef("c", List(), 2))),
    ("interp app1", 9, App("f", List(5)), funDefs),
    (
      "interp app2",
      3,
      App("f", List(1, 2)),
      Map("f" -> FunDef("f", List("x", "y"), Add("x", "y")))
    ),
    (
      "interp app3",
      0,
      App("g", List(1, 2, 3)),
      Map("g" -> FunDef("g", List("x", "y", "z"), Add("x", Sub("y", "z"))))
    ),
    ("interp let", 2, Let("y", 2, "y"), Map.empty[String, FunDef]),
    (
      "interp let app2",
      1,
      Let("y", 2, App("f", List("y", 1))),
      Map("f" -> FunDef("f", List("x", "y"), Sub("x", "y")))
    ),
    (
      "interp let let app2",
      1,
      Let("y", 2, Let("x", 1, App("f", List("y", "x")))),
      Map("f" -> FunDef("f", List("x", "y"), Sub("x", "y")))
    ),
    (
      "interp app, expr in arg",
      3,
      App("f", List(Let("x", 2, Sub("x", 1)), 2)),
      Map("f" -> FunDef("f", List("x", "y"), Add("x", "y")))
    ),
    (
      "interp app1, let in add",
      7,
      App("f", List(5)),
      Map("f" -> FunDef("f", List("x"), Add(Let("x", 2, "x"), "x")))
    ),
    (
      "interp app2, let in add, 1",
      4,
      App("f", List(1, 2)),
      Map("f" -> FunDef("f", List("x", "y"), Add(Let("x", 2, "x"), "y")))
    ),
    (
      "interp app2, let in add, 2",
      4,
      App("f", List(5, 2)),
      Map("f" -> FunDef("f", List("x", "y"), Add(Let("x", 2, "x"), "y")))
    ),
    (
      "interp complex",
      42,
      Let(
        "y",
        App("A", List()),
        Let(
          "x",
          Sub("y", 25),
          App(
            "f",
            List(
              "x",
              Sub("y", App("f", List(Sub(App("f", List("x", 1)), 1), App("f", List(20, 3)))))
            )
          )
        )
      ),
      Map("f" -> FunDef("f", List("x", "y"), Add("x", "y")), "A" -> FunDef("A", List(), 65))
    )
  )

  forAll(testcases) { case (name, expectation, expr, funDefs) =>
    test(s"Interpret $name") {
      assertResult(expectation) { interp(expr, funDefs) }
    }
  }
