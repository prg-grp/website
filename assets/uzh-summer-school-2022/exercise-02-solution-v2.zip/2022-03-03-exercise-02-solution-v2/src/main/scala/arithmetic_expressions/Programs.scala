package arithmetic_expressions

object Programs:

  sealed trait LAE
  case class Num(n: Int) extends LAE
  case class Add(lhs: LAE, rhs: LAE) extends LAE
  case class Let(name: String, namedExpr: LAE, body: LAE) extends LAE
  case class Id(name: String) extends LAE

  def progSize(p: LAE): Int = ???

  def freeVars(p: LAE): Set[String] = ???

  // def foldProg(???): ??? = ???

  def progSizeFold(p: LAE): Int = ???

  def freeVarsFold(p: LAE): Set[String] = ???
