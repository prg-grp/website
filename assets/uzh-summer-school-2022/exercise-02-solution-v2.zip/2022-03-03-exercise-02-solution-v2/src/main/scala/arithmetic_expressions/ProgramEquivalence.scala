package arithmetic_expressions

object ProgramEquivalence:

  import Programs.*

  def subst(expr: LAE, substId: String, value: LAE): LAE = expr match
    case Num(_) => expr
    case Add(lhs, rhs) =>
      Add(subst(lhs, substId, value), subst(rhs, substId, value))
    case Let(boundId, namedExpr, boundExpr) =>
      val substNamedExpr = subst(namedExpr, substId, value)
      if boundId == substId then Let(boundId, substNamedExpr, boundExpr)
      else Let(boundId, substNamedExpr, subst(boundExpr, substId, value))
    case Id(name) => if substId == name then value else expr

  def interp(expr: LAE): Int = expr match
    case Num(n)        => n
    case Add(lhs, rhs) => interp(lhs) + interp(rhs)
    case Let(boundId, namedExpr, boundExpr) =>
      interp(subst(boundExpr, boundId, namedExpr))
    case Id(name) => sys.error("found unbound id " + name)
