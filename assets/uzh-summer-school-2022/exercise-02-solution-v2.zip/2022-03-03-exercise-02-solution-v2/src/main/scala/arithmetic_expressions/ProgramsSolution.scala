package arithmetic_expressions

object ProgramsSolution:

  sealed trait LAE
  case class Num(n: Int) extends LAE
  case class Add(lhs: LAE, rhs: LAE) extends LAE
  case class Let(name: String, namedExpr: LAE, body: LAE) extends LAE
  case class Id(name: String) extends LAE

  def progSize(p: LAE): Int = p match
    case Num(_)          => 1
    case Id(_)           => 1
    case Add(e1, e2)     => 1 + progSize(e1) + progSize(e2)
    case Let(_, e, body) => 1 + progSize(e) + progSize(body)

  def freeVars(p: LAE): Set[String] = p match
    case Num(_)          => Set.empty
    case Id(x)           => Set(x)
    case Add(e1, e2)     => freeVars(e1) ++ freeVars(e2)
    case Let(x, e, body) => freeVars(e) ++ (freeVars(body) - x)

  def foldProg[T](
      numF: Int => T,
      idF: String => T,
      addF: (T, T) => T,
      letF: (String, T, T) => T,
      p: LAE
  ): T =
    def fold(pp: LAE): T = foldProg(numF, idF, addF, letF, pp)
    p match
      case Num(n)          => numF(n)
      case Id(x)           => idF(x)
      case Add(e1, e2)     => addF(fold(e1), fold(e2))
      case Let(x, e, body) => letF(x, fold(e), fold(body))

  def progSizeFold(p: LAE): Int =
    foldProg[Int](n => 1, x => 1, (v1, v2) => 1 + v1 + v2, (x, v0, v1) => 1 + v0 + v1, p)

  def freeVarsFold(p: LAE): Set[String] =
    foldProg[Set[String]](
      n => Set.empty,
      x => Set(x),
      (v1, v2) => v1 ++ v2,
      (x, v0, v1) => v0 ++ (v1 - x),
      p
    )
