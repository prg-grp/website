package first_order_functions

object MultipleArgumentsSolution:
  given Conversion[String, Id] with
    def apply(s: String): Id = Id(s)
  given Conversion[Int, Num] with
    def apply(n: Int): Num = Num(n)

  // AST for expressions of F1LAE
  sealed abstract class F1LAE
  case class Num(n: Int) extends F1LAE
  case class Add(lhs: F1LAE, rhs: F1LAE) extends F1LAE
  case class Sub(lhs: F1LAE, rhs: F1LAE) extends F1LAE
  case class Let(name: String, namedExpr: F1LAE, body: F1LAE) extends F1LAE
  case class Id(name: String) extends F1LAE
  case class App(funName: String, args: List[F1LAE]) extends F1LAE

  // AST for function definition forms in F1LAE
  case class FunDef(funName: String, argNames: List[String], body: F1LAE)
  type FunDefs = Map[String, FunDef]

  // evaluates F1LAE expressions by reducing them to their corresponding values
  def interp(expr: F1LAE, funDefs: FunDefs): Int = expr match
    case Num(n)        => n
    case Add(lhs, rhs) => interp(lhs, funDefs) + interp(rhs, funDefs)
    case Sub(lhs, rhs) => interp(lhs, funDefs) - interp(rhs, funDefs)
    case Id(name)      => sys.error("found unbound id " + name)
    case Let(boundId, namedExpr, boundExpr) =>
      interp(subst(boundExpr, boundId, Num(interp(namedExpr, funDefs))), funDefs)
    case App(funName, argExprs) =>
      funDefs(funName) match
        case FunDef(_, argNames, body) =>
          val namesAndExprs = argNames zip argExprs
          val substBody = namesAndExprs.foldLeft(body)((bodyAcc, nameAndExpr) =>
            val (argName, argExpr) = nameAndExpr
            subst(bodyAcc, argName, interp(argExpr, funDefs))
          )
          interp(substBody, funDefs)
        case _ => sys.error(s"function not found: $funName")

  // substitutes 2nd argument with 3rd argument in 1st argument. The resulting
  // expression contains no free instances of the 2nd argument.
  def subst(expr: F1LAE, substId: String, value: F1LAE): F1LAE = expr match
    case Num(n)        => expr
    case Add(lhs, rhs) => Add(subst(lhs, substId, value), subst(rhs, substId, value))
    case Sub(lhs, rhs) => Sub(subst(lhs, substId, value), subst(rhs, substId, value))
    case Id(name)      => if (substId == name) value else expr
    case Let(boundId, namedExpr, boundExpr) =>
      val substNamedExpr = subst(namedExpr, substId, value)
      if (boundId == substId)
        Let(boundId, substNamedExpr, boundExpr)
      else
        Let(boundId, substNamedExpr, subst(boundExpr, substId, value))
    case App(funName, argExprs) => App(funName, argExprs map (subst(_, substId, value)))
