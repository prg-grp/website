package first_order_functions

import If0.*

object Fibonacci:

  // Define your function here
  // (the example definition always returns the argument n)
  val fibDefs = Map("fib" -> FunDef("fib", "n", "n"))
