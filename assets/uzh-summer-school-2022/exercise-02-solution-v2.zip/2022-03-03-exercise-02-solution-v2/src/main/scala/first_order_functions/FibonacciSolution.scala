package first_order_functions

import If0Solution.*

object FibonacciSolution:

  val fibDefs = Map(
    // @formatter:off
    "fib" -> FunDef("fib", "n",
      If0("n", 0,
        If0(Sub("n", 1), 1,
          Add(
            App("fib", Sub("n", 1)),
            App("fib", Sub("n", 2))
      )))
    )
    // @formatter:on
  )
