package higher_order_functions

object ArithmeticsSolution:

  def sum(l: List[Int]): Int = l match
    case Nil     => 0
    case x :: xs => x + sum(xs)

  def prod(l: List[Int]): Int = l match
    case Nil     => 1
    case x :: xs => x * prod(xs)

  def fold[A, R](l: List[A])(init: R, op: (A, R) => R): R = l match
    case Nil     => init
    case x :: xs => op(x, fold(xs)(init, op))

//  // Alternative solution:
//  def fold(l: List[Int])(init: Int, op: (Int, Int) => Int): Int = l match
//    case Nil     => init
//    case x :: xs => op(x, fold(xs)(init, op))

//  // Alternative solution:
//  def fold(l: List[Int])(init: Int, op: (Int, Int) => Int): Int =
//    def rec(l: List[Int]): Int = l match
//      case Nil     => init
//      case x :: xs => op(x, rec(xs))
//    rec(l)

  def sumFold(l: List[Int]): Int =
    fold(l)(0, _ + _)

  def prodFold(l: List[Int]): Int =
    fold(l)(1, _ * _)
