package higher_order_functions

object Trees:

  trait Tree[A]
  case class Leaf[A](a: A) extends Tree[A]
  case class Node[A](l: Tree[A], r: Tree[A]) extends Tree[A]

  def sumTree(l: Tree[Int]): Int = ???

  def collectTree[A](l: Tree[A]): Set[A] = ???

//  def foldTree(???): ??? = ???

  def sumTreeFold(tree: Tree[Int]): Int = ???

  def collectTreeFold[A](tree: Tree[A]): Set[A] = ???
