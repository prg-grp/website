package higher_order_functions

object TreesSolution:

  trait Tree[A]
  case class Leaf[A](a: A) extends Tree[A]
  case class Node[A](l: Tree[A], r: Tree[A]) extends Tree[A]

  def sumTree(tree: Tree[Int]): Int = tree match
    case Leaf(a)    => a // identity(a)
    case Node(l, r) => sumTree(l) + sumTree(r)

  def collectTree[A](tree: Tree[A]): Set[A] = tree match
    case Leaf(a)    => Set(a)
    case Node(l, r) => collectTree(l) ++ collectTree(r)

  def foldTree[A, R](tree: Tree[A])(leaf: A => R, node: (R, R) => R): R =
    def rec(t: Tree[A]): R = t match {
      case Leaf(a)    => leaf(a)
      case Node(l, r) => node(rec(l), rec(r))
    }
    rec(tree)

  def sumTreeFold(tree: Tree[Int]): Int =
    foldTree[Int, Int](tree)(identity, _ + _)

  def collectTreeFold[A](tree: Tree[A]): Set[A] =
    foldTree[A, Set[A]](tree)(Set(_), _ ++ _)
