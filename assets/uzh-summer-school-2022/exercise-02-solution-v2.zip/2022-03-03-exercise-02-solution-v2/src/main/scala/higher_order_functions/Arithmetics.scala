package higher_order_functions

object Arithmetics:

  def sum(l: List[Int]): Int = ???

  def prod(l: List[Int]): Int = ???

//  def fold(???) : ??? = ???

  def sumFold(l: List[Int]): Int = ???

  def prodFold(l: List[Int]): Int = ???
